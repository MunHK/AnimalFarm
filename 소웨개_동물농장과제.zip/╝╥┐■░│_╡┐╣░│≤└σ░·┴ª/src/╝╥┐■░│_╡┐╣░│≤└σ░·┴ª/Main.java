package 소웨개_동물농장과제;

public class Main {

	public static void main(String[] args) {
		Dog dog = new Dog("멍멍이",20,"흰색");
		Cat cat = new Cat("야옹이",10,"검은색");
		Chicken chicken = new Chicken("꼬댁이",5,"빨간색");
		
		dog.speak();
		cat.speak();
		chicken.speak();
	}

}
