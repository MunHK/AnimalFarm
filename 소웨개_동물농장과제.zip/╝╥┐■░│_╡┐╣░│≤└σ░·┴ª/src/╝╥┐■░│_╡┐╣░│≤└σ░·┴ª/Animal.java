package 소웨개_동물농장과제;

public class Animal {
	String name;
	int weight;
	String color;
	
	Animal(String n,int w,String c){
		this.name=n;
		this.weight=w;
		this.color=c;
	}
	void speak() {
		System.out.println("소리내기");
	}
	String speak1() {
		return "소리내기";
	}
	public String getName() {
		return name;
	}
	public int getWeight() {
		return weight;
	}
	public String getColor() {
		return color;
	}
}
