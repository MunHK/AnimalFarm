package 소웨개_동물농장과제;

public class Dog extends Animal{
	Dog(String n, int w, String c) {
		super(n, w, c);
		// TODO Auto-generated constructor stub
	}

	void speak() {
		System.out.println("멍멍");
	}
	String speak1() {
		return "멍멍";
	}
}
