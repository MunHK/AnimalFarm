package 소웨개_동물농장과제;

import java.util.ArrayList;


public class AnimalFarm {
	public static void main(String[] args) {
		ArrayList<Animal> animals = new ArrayList<Animal>();
		
		animals.add(new Dog("흰둥이",20,"흰색"));
		animals.add(new Cat("캣둥이",10,"검은색"));
		animals.add(new Chicken("꼬둥이",5,"빨간색"));

		System.out.println("==================");
		for(int i=0;i<animals.size();i++) {
			System.out.printf("%3s | %2d | %3s |\n",animals.get(i).name,animals.get(i).weight,animals.get(i).color);
			System.out.println("==================");
		}
		for(int i=0;i<animals.size();i++) {
			System.out.printf("%s : %s \n",animals.get(i).name,animals.get(i).speak1());
		}
	}
}
